extends Control

@onready
var board = get_node('Board')

@onready
var end_game_screen = get_node('EndGame')

@onready
var hand_board = get_node('hand')

var player_1 : Player
var player_2 : Player
var player_1_continue = true
var player_2_continue = true
var player_active = true

var deck : Array

func generate_deck():
	var cards = []
	var houses = ["Paus", "Espadas", "Ouro", "Copas"]
	
	for np in houses:
		for i in range(1, 14):
			cards.append( Card.new(i, np) )
	return cards

func updateBoard():
	board.text = 'Vez do ' + (player_1.player_name if player_active else player_2.player_name)
	board.text += ' | Jogador ' + player_1.player_name + ' - ' + str(player_1.score) + ' pontos '
	board.text += ' | Jogador ' + player_2.player_name + ' - ' + str(player_2.score) + ' pontos '
	
	board.text += '\n' + player_1.show_hands()
	board.text += '\n' + player_2.show_hands()

func end_game():
	var result = ''
	if( player_1.score == player_2.score ):
		result = 'Os jogadores optaram por empate'
	elif( player_1.score > 21 ):
		result = player_2.player_name
	elif( player_2.score > 21 ):
		result = player_1.player_name
	elif(player_1.score > player_2.score ):
		result = player_1.player_name
	else:
		result = player_2.player_name
	
	end_game_screen.text = result + ' venceu!!'

func _ready():
	player_1 = Player.new('A')
	player_2 = Player.new('B')
	
	print('Gerando baralho')
	deck = generate_deck()
	
	print('Embaralhando')
	deck.shuffle()

	print('Entregando duas cartas para cada jogador')
	board.text += ''
	
	updateBoard()

func _on_puxar_button_up() -> void:
	if( player_active ):
		player_1.take_card( deck )
		hand_board.add_child(player_1.hand[-1].interface)
		player_1.hand[-1].interface.position.x = (len(player_1.hand)-1)*150
		player_1.hand[-1].interface.get_node('paper').size.y = 220
	else:
		player_2.take_card( deck )
		player_2.hand[-1].interface.position.y = 230
		player_2.hand[-1].interface.position.x = (len(player_1.hand)-1)*150
		hand_board.add_child(player_2.hand[-1].interface)
		
	if( player_1.score == 21 or player_2.score == 21 ):
		end_game()
	elif( player_1.score < 22 and player_2.score < 22 ):
		player_active = not player_active
	else:
		end_game()
	updateBoard()

func _on_manter_button_up() -> void:
	if( player_active):
		player_1_continue = false
	else:
		player_2_continue = false
	
	if( not player_1_continue and not player_2_continue ):
		end_game()
	player_active = not player_active


func _on_btn_reset_button_up() -> void:
	print('Gerando baralho')
	deck = generate_deck()
	
	print('Embaralhando')
	deck.shuffle()
	player_active = true

	end_game_screen.text = ''
	
	# limpar as mãos dos jogadores
	player_1.reset( hand_board, deck )
	player_2.reset( hand_board, deck )
	
	updateBoard()
